
Configuration
-------------

 - Edit cyrus.conf and set $cyrus_* variables correctly. User must have permission over all accounts.
 - Edit cyrus-*.pl and change path to cyrus.conf (require '/path/to/cyrus.conf'; line)

